

module mux_8 (A,h_1,h_3,h_5,h_7,h_9,h_11,h_13,h_15,sel);
input [2:0]sel;
input [15:0] h_1,h_3,h_5,h_7,h_9,h_11,h_13,h_15 ;
output reg [15:0] A;
always@(*)
begin 
case(sel)
3'b000:A=h_1;
3'b001:A=h_3;
3'b010:A=h_5;
3'b011:A=h_7;
3'b100:A=h_9;
3'b101:A=h_11;
3'b110:A=h_13;
3'b111:A=h_15;
endcase
end
endmodule

