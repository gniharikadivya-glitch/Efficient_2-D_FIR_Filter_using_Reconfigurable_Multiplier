`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 23.08.2024 13:50:14
// Design Name: 
// Module Name: d_ff
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module d_ff (clk,rst,d,q);
input clk,rst;
input [21:0] d;
output reg [21:0]  q;

always@(posedge clk)
begin
	if(rst)
	q<=22'd0;
	else 
	q<=d;
end
endmodule

