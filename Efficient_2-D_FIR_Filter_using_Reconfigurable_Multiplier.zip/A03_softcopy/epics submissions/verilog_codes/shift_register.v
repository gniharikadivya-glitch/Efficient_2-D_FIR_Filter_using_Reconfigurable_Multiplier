module shift_register(
    input wire clk,
    input wire i_rst,
    input wire [7:0] i_serial_in,  // 8-bit wide input
    output wire [7:0] o_serial_out // 8-bit wide output
);

reg [7:0] shift_reg [255:0];  // 256x8-bit shift register
integer i;
integer j;

// Shift register operation
always @(posedge clk or posedge i_rst)
begin
    if (i_rst) begin
        
        for (i = 0; i < 256; i = i + 1) 
            shift_reg[i] <= 8'b0;  // Reset the entire shift register
    end else begin
        
        for (j = 255; j > 0; j = j - 1)
            shift_reg[j] <= shift_reg[j-1];  // Shift data to the right
        shift_reg[0] <= i_serial_in;          // Load new 8-bit data into the first stage
    end
end

// Output the last stage of the shift register
assign o_serial_out = shift_reg[255];

endmodule
