

module adder_22 (product,IS1,IS2,cin);
input [21:0]IS1,IS2;
input cin;
output wire [21:0] product;
wire c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21;
fa am0(c0,product[0],IS1[0],IS2[0],cin);
fa am1(c1,product[1],IS1[1],IS2[1],c0);
fa am2(c2,product[2],IS1[2],IS2[2],c1);
fa am3(c3,product[3],IS1[3],IS2[3],c2);
fa am4(c4,product[4],IS1[4],IS2[4],c3);
fa am5(c5,product[5],IS1[5],IS2[5],c4);
fa am6(c6,product[6],IS1[6],IS2[6],c5);
fa am7(c7,product[7],IS1[7],IS2[7],c6);
fa am8(c8,product[8],IS1[8],IS2[8],c7);
fa am9(c9,product[9],IS1[9],IS2[9],c8);
fa am10(c10,product[10],IS1[10],IS2[10],c9);
fa am11(c11,product[11],IS1[11],IS2[11],c10);
fa am12(c12,product[12],IS1[12],IS2[12],c11);
fa am13(c13,product[13],IS1[13],IS2[13],c12);
fa am14(c14,product[14],IS1[14],IS2[14],c13);
fa am15(c15,product[15],IS1[15],IS2[15],c14);
fa am16(c16,product[16],IS1[16],IS2[16],c15);
fa am17(c17,product[17],IS1[17],IS2[17],c16);
fa am18(c18,product[18],IS1[18],IS2[18],c17);
fa am19(c19,product[19],IS1[19],IS2[19],c18);
fa am20(c20,product[20],IS1[20],IS2[20],c19);
fa am21(c21,product[21],IS1[21],IS2[21],c20);

endmodule
