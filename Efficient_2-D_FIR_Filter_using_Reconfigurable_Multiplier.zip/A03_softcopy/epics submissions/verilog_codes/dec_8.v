
module dec_8 (
input [7:0]x ,
output [5:0]sel,
output [3:0]sft,
output [1:0]nze
);

assign sel[0]=(x[0]&x[1])|(x[1]&x[2])|((~x[0])&x[2]&x[3]);
assign sel[1]=(x[0]&x[2])|((~x[0])&x[1]&x[3]);
assign sel[2]=(x[0]&x[3]);
assign sft[0]=((~x[0])&x[1])|(x[3]&(~x[0])&(~x[2]));
assign sft[1]=(x[2]&(~x[1])&(~x[0]))|(x[3]&(~x[1])&(~x[0]));
assign nze[0]=(x[0]|x[1]|x[3]|x[2]);
assign sel[3]=(x[4]&x[5])|(x[5]&x[6])|((~x[4])&x[6]&x[7]);
assign sel[4]=(x[4]&x[6])|((~x[4])&x[5]&x[7]);
assign sel[5]=(x[4]&x[7]);
assign sft[2]=((~x[4])&x[5])|(x[7]&(~x[4])&(~x[6]));
assign sft[3]=(x[6]&(~x[5])&(~x[4]))|(x[7]&(~x[5])&(~x[4]));
assign nze[1]=(x[4]|x[5]|x[7]|x[6]);

endmodule
