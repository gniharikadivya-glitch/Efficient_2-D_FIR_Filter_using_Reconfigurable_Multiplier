`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/28/2024 04:48:20 PM
// Design Name: 
// Module Name: fir_2d
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fir_2d_new (clk, reset,x_in,y_out);
input clk, reset;
input [7:0] x_in;
output [21:0] y_out;

wire [7:0] sr1;
wire [21:0] y_out1;
shift_register sh1(clk, reset, x_in, sr1);
row_filter rf1 (clk, reset,x_in,y_out1);

wire [7:0] sr2;
wire [21:0] y_out2;
shift_register sh2(clk, reset, sr1, sr2);
row_filter rf2 (clk, reset,sr1,y_out2);

wire [7:0] sr3;
wire [21:0] y_out3;
shift_register sh3(clk, reset, sr2, sr3);
row_filter rf3 (clk, reset,sr2,y_out3);


wire [7:0] sr4;
wire [21:0] y_out4;
shift_register sh4(clk, reset, sr3, sr4);
row_filter rf4 (clk, reset,sr3,y_out4);

wire [7:0] sr5;
wire [21:0] y_out5;
shift_register sh5(clk, reset, sr4, sr5);
row_filter rf5 (clk, reset,sr4,y_out5);


wire [7:0] sr6;
wire [21:0] y_out6;
shift_register sh6(clk, reset, sr5, sr6);
row_filter rf6 (clk, reset,sr5,y_out6);


wire [7:0] sr7;
wire [21:0] y_out7;
shift_register sh7(clk, reset, sr6, sr7);
row_filter rf7 (clk, reset,sr7,y_out7);

wire [7:0] sr8;
wire [21:0] y_out8;
shift_register sh8(clk, reset, sr7, sr8);
row_filter rf8 (clk, reset,sr8,y_out8);


wire [7:0] sr9;
wire [21:0] y_out9;
shift_register sh9(clk, reset, sr8, sr9);
row_filter rf9 (clk, reset,sr9,y_out9);


wire [7:0] sr10;
wire [21:0] y_out10;
shift_register sh10(clk, reset, sr9, sr10);
row_filter rf10 (clk, reset,sr9,y_out10);

wire [7:0] sr11;
wire [21:0] y_out11;
shift_register sh11(clk, reset, sr10, sr11);
row_filter rf11 (clk, reset,sr10,y_out11);

wire [21:0] a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;

adder_22 dut_add1 (a1,y_out1,y_out2,1'b0);
adder_22 dut_add2 (a2,y_out3,y_out4,1'b0);
adder_22 dut_add3 (a3,y_out5,y_out6,1'b0);
adder_22 dut_add4 (a4,y_out7,y_out8,1'b0);
adder_22 dut_add5 (a5,y_out9,y_out10,1'b0);
adder_22 dut_add6 (a6,a1,a2,1'b0);
adder_22 dut_add7 (a7,a3,a4,1'b0);
adder_22 dut_add8 (a8,a5,y_out11,1'b0);
adder_22 dut_add9 (a9,a6,a7,1'b0);
adder_22 dut_add10 (a10,a8,a9,1'b0);

assign y_out=[9:0]a10;

endmodule
