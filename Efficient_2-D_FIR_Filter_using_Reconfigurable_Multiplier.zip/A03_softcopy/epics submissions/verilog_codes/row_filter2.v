
module row_filter2 (clk, rst,x_in,y_out);
input clk, rst;
input [7:0] x_in;
output [21:0] y_out;

wire [21:0] product_h0,product_h1,product_h2,product_h3,product_h4,product_h5;
wire [15:0] h0_1,h0_3,h0_5,h0_7,h0_9,h0_11,h0_13,h0_15;
wire [15:0] h1_1,h1_3,h1_5,h1_7,h1_9,h1_11,h1_13,h1_15;
wire [15:0] h2_1,h2_3,h2_5,h2_7,h2_9,h2_11,h2_13,h2_15;
wire [15:0] h3_1,h3_3,h3_5,h3_7,h3_9,h3_11,h3_13,h3_15;
wire [15:0] h4_1,h4_3,h4_5,h4_7,h4_9,h4_11,h4_13,h4_15;
wire [15:0] h5_1,h5_3,h5_5,h5_7,h5_9,h5_11,h5_13,h5_15;

assign h0_1  = 16'd1;
assign h0_3  = 16'd4;
assign h0_5  = 16'd7;
assign h0_7  = 16'd10;
assign h0_9  = 16'd13;
assign h0_11 = 16'd15;
assign h0_13 = 16'd18;
assign h0_15 = 16'd21;


assign h1_1  = 16'd8;
assign h1_3  = 16'd23;
assign h1_5  = 16'd38;
assign h1_7  = 16'd53;
assign h1_9  = 16'd68;
assign h1_11 = 16'd83;
assign h1_13 = 16'd98;
assign h1_15 = 16'd113;

assign h2_1  = 16'd11;
assign h2_3  = 16'd33;
assign h2_5  = 16'd55;
assign h2_7  = 16'd78;
assign h2_9  = 16'd100;
assign h2_11 = 16'd122;
assign h2_13 = 16'd144;
assign h2_15 = 16'd166;


assign h3_1  = -16'd14;
assign h3_3  = -16'd41;
assign h3_5  = -16'd68;
assign h3_7  = -16'd95;
assign h3_9  = -16'd122;
assign h3_11 = -16'd149;
assign h3_13 = -16'd177;
assign h3_15 = -16'd204;

assign h4_1  = -16'd69;
assign h4_3  = -16'd207;
assign h4_5  = -16'd345;
assign h4_7  = -16'd484;
assign h4_9  = -16'd622;
assign h4_11 = -16'd760;
assign h4_13 = -16'd898;
assign h4_15 = -16'd1036;

assign h5_1  = -16'd101;
assign h5_3  = -16'd303;
assign h5_5  = -16'd505;
assign h5_7  = -16'd707;
assign h5_9  = -16'd909;
assign h5_11 = -16'd1111;
assign h5_13 = -16'd1314;
assign h5_15 = -16'd1516;


pg_8 h0 (product_h0,h0_1,h0_3,h0_5,h0_7,h0_9,h0_11,h0_13,h0_15,x_in);
pg_8 h1 (product_h1,h1_1,h1_3,h1_5,h1_7,h1_9,h1_11,h1_13,h1_15,x_in);
pg_8 h2 (product_h2,h2_1,h2_3,h2_5,h2_7,h2_9,h2_11,h2_13,h2_15,x_in);
pg_8 h3 (product_h3,h3_1,h3_3,h3_5,h3_7,h3_9,h3_11,h3_13,h3_15,x_in);
pg_8 h4 (product_h4,h4_1,h4_3,h4_5,h4_7,h4_9,h4_11,h4_13,h4_15,x_in);
pg_8 h5 (product_h5,h5_1,h5_3,h5_5,h5_7,h5_9,h5_11,h5_13,h5_15,x_in);

wire [21:0] q1;

d_ff df0 (clk,rst,product_h0,q1);

wire [21:0] add_0;
adder_22 add0 (add_0,q1,product_h1,1'b0);

wire [21:0] q2;
d_ff df1 (clk,rst,add_0,q2);

wire [21:0] add_1;
adder_22 add1 (add_1,q2,product_h2,1'b0);


wire [21:0] q3;
d_ff df2 (clk,rst,add_1,q3);

wire [21:0] add_2;
adder_22 add2 (add_2,q3,product_h3,1'b0);

wire [21:0] q4;
d_ff df3 (clk,rst,add_2,q4);

wire [21:0] add_3;
adder_22 add3 (add_3,q4,product_h4,1'b0);

wire [21:0] q5;
d_ff df4 (clk,rst,add_3,q5);

wire [21:0] add_4;
adder_22 add4 (add_4,q5,product_h5,1'b0);

wire [21:0] q6;
d_ff df5 (clk,rst,add_4,q6);

wire [21:0] add_5;
adder_22 add5 (add_5,q6,product_h4,1'b0);

wire [21:0] q7;
d_ff df6 (clk,rst,add_5,q7);

wire [21:0] add_6;
adder_22 add6 (add_6,q7,product_h3,1'b0);

wire [21:0] q8;
d_ff df7 (clk,rst,add_6,q8);

wire [21:0] add_7;
adder_22 add7 (add_7,q8,product_h2,1'b0);

wire [21:0] q9;
d_ff df8 (clk,rst,add_7,q9);

wire [21:0] add_8;
adder_22 add8 (add_8,q9,product_h1,1'b0);

wire [21:0] q10;
d_ff df9 (clk,rst,add_8,q10);

adder_22 add9 (y_out,q10,product_h0,1'b0);


endmodule
