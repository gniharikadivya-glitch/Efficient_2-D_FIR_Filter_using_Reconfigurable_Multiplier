

module a_8 (IS,D,E);

input E;
input [17:0] D;
output [17:0] IS;
assign IS = {{18{E}}&D};

endmodule

