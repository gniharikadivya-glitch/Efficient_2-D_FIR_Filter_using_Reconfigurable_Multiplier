module adder_18(out, in1, in2, cin);
  input [17:0] in1, in2;
  input cin;
  output [17:0] out;

  assign out = in1 + in2 + cin;
endmodule