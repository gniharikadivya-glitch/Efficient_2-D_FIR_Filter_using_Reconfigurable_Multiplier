`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:19:39
// Design Name: 
// Module Name: row_filter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module row_filter(clk, reset, x_in, y_out);
  input clk, reset;
  input [7:0] x_in;
  output reg [17:0] y_out;

  reg [7:0] taps[0:3];           // 4-tap shift register
  reg [7:0] coeffs[0:3];         // Coefficients

  integer i;

  initial begin
    coeffs[0] = 8'd1;
    coeffs[1] = 8'd2;
    coeffs[2] = 8'd3;
    coeffs[3] = 8'd4;
  end

  always @(posedge clk or posedge reset) begin
    if (reset) begin
      for (i = 0; i < 4; i = i + 1)
        taps[i] <= 8'd0;
      y_out <= 18'd0;
    end else begin
      // Shift tap values
      taps[3] <= taps[2];
      taps[2] <= taps[1];
      taps[1] <= taps[0];
      taps[0] <= x_in;

      // FIR multiply-accumulate
      y_out <= taps[0]*coeffs[0] + taps[1]*coeffs[1] + taps[2]*coeffs[2] + taps[3]*coeffs[3];
    end
  end
endmodule


 
