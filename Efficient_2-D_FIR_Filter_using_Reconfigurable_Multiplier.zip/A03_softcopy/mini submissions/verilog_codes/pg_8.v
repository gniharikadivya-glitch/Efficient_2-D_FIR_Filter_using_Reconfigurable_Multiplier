`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:26:04
// Design Name: 
// Module Name: pg_8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pg_8 (product,h_1,h_3,x);
input [15:0] h_1,h_3;
input [7:0] x;
output[17:0] product;
wire [5:0] sel;
wire [3:0] sft;
wire [1:0] nze;

dec_8 dut1(x,sel,sft,nze);

wire [15:0] A;

mux_8 dut2(A,h_1,h_3,sel[2:0]);

wire [15:0] A1;

mux_8 dut3(A1,h_1,h_3,sel[5:3]);

wire [17:0] D;

ishifter_8 dut4(A,sft[1:0],D);

wire [17:0] D1;

ishifter_8 dut5(A1,sft[3:2],D1);

wire [17:0] IS1;
a_8 dut6(IS1,D,nze[0]);
wire [17:0] IS2;
a_8 dut7(IS2,D1,nze[1]);

wire [17:0] product;
adder_18 dut8(product,{{4{IS1[17]}},IS1},{IS2,4'd0},1'b0);




endmodule

