`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:30:53
// Design Name: 
// Module Name: d_ff
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module d_ff (clk,rst,q,d);
input clk,rst;
input [17:0] d;
output reg [17:0]  q;

always@(posedge clk)
begin
	if(rst)
	q<=18'd0;
	else 
	q<=d;
end
endmodule