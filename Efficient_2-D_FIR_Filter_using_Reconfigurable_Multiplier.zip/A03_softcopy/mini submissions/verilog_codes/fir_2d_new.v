`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:17:11
// Design Name: 
// Module Name: fir_2d_new
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module fir_2d_new (clk, reset, x_in, y_out);
  input clk, reset;
  input [7:0] x_in;
  output [17:0] y_out;

  wire [7:0] sr1, sr2, sr3;
  wire [17:0] y_out1, y_out2, y_out3, y_out4;

  // Shift Registers
  shift_register sh1(clk, reset, x_in, sr1);
  shift_register sh2(clk, reset, sr1, sr2);
  shift_register sh3(clk, reset, sr2, sr3);

  // Row Filters
  row_filter rf1(clk, reset, x_in, y_out1);
  row_filter rf2(clk, reset, sr1, y_out2);
  row_filter rf3(clk, reset, sr2, y_out3);
  row_filter rf4(clk, reset, sr3, y_out4);

  // Adders
  wire [17:0] a1, a2, a3;

  adder_18 dut_add1(a1, y_out1, y_out2, 1'b0);
  adder_18 dut_add2(a2, y_out3, y_out4, 1'b0);
  adder_18 dut_add3(a3, a1, a2, 1'b0);

  // Final Output
  assign y_out = a3;

endmodule
