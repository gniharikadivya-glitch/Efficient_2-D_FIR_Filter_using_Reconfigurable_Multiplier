module shift_register(clk, reset, din, dout);
  input clk, reset;
  input [7:0] din;
  output reg [7:0] dout;

  always @(posedge clk or posedge reset) begin
    if (reset)
      dout <= 8'd0;
    else
      dout <= din;
  end
endmodule