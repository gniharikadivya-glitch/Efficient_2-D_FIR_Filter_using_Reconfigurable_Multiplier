`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:26:54
// Design Name: 
// Module Name: mux_8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module mux_8 (A,h_1,h_3,sel);
input [2:0]sel;
input [15:0] h_1,h_3 ;
output reg [15:0] A;
always@(*)
begin 
case(sel)
3'b000:A=h_1;
3'b001:A=h_3;

endcase
end
endmodule

