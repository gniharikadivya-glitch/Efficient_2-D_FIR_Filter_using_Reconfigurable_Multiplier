`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 29.04.2025 19:28:18
// Design Name: 
// Module Name: ishifter_8
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module ishifter_8 (
input wire [15:0] A,
input wire [1:0] B,
output reg [17:0] D
);    
always@*
begin
case(B)
2'b00: D={{3{A[15]}},A};
2'b01: D={{2{A[15]}},A,1'b0}; 
2'b10: D={{1{A[15]}},A,2'b0}; 
2'b11: D={A,3'b0}; 
endcase
end
endmodule
